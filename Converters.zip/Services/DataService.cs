﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using MedicalDiaryWPF.Models;
using Newtonsoft.Json;

namespace MedicalDiaryWPF.Services
{
    public class DataService
    {
        private readonly string _filePath = "data.json";
        private List<Record> _records = new();
        private int _nextId = 1;

        public List<Record> Records => _records.OrderByDescending(r => r.DateTime).ToList();

        public DataService() => Load();

        public void Add(Record record)
        {
            record.Id = _nextId++;
            _records.Add(record);
            Save();
        }

        public void Update(Record record)
        {
            var existing = _records.FirstOrDefault(r => r.Id == record.Id);
            if (existing != null)
            {
                existing.DateTime = record.DateTime;
                existing.Systolic = record.Systolic;
                existing.Diastolic = record.Diastolic;
                existing.Pulse = record.Pulse;
                existing.Sugar = record.Sugar;
                existing.Meal = record.Meal;
                existing.Comment = record.Comment;
                Save();
            }
        }

        public void Delete(int id)
        {
            var record = _records.FirstOrDefault(r => r.Id == id);
            if (record != null)
            {
                _records.Remove(record);
                Save();
            }
        }

        public void Save()
        {
            var json = JsonConvert.SerializeObject(_records, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(_filePath, json);
        }

        public void Load()
        {
            if (!File.Exists(_filePath)) return;
            try
            {
                var json = File.ReadAllText(_filePath);
                _records = JsonConvert.DeserializeObject<List<Record>>(json) ?? new List<Record>();
                _nextId = _records.Any() ? _records.Max(r => r.Id) + 1 : 1;
            }
            catch
            {
                _records = new List<Record>();
                _nextId = 1;
            }
        }
    }
}