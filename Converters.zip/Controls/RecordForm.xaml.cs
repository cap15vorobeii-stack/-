﻿using System;
using System.Windows;
using MedicalDiaryWPF.Models;
using MedicalDiaryWPF.Services;

namespace MedicalDiaryWPF.Controls
{
    public partial class RecordForm : Window
    {
        private readonly DataService _dataService;
        private readonly Record _editingRecord;
        private readonly bool _isEditMode;

        public RecordForm(DataService dataService, Record record = null)
        {
            InitializeComponent();
            _dataService = dataService;
            _editingRecord = record;
            _isEditMode = record != null;
            Title = _isEditMode ? "Редактирование записи" : "Новая запись";

            if (_isEditMode)
                LoadRecordToForm();
        }

        private void LoadRecordToForm()
        {
            dpDate.SelectedDate = _editingRecord.DateTime.Date;
            tbTime.Text = _editingRecord.DateTime.ToString("HH:mm");
            tbSystolic.Text = _editingRecord.Systolic.ToString();
            tbDiastolic.Text = _editingRecord.Diastolic.ToString();
            tbPulse.Text = _editingRecord.Pulse.ToString();
            tbSugar.Text = _editingRecord.Sugar.ToString("F1");
            cbMeal.SelectedIndex = (int)_editingRecord.Meal;
            tbComment.Text = _editingRecord.Comment;
        }

        private bool ValidateFields()
        {
            if (!int.TryParse(tbSystolic.Text, out int systolic) || systolic < 60 || systolic > 250)
            {
                MessageBox.Show("Систолическое давление должно быть 60-250", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                tbSystolic.Focus();
                return false;
            }
            if (!int.TryParse(tbDiastolic.Text, out int diastolic) || diastolic < 40 || diastolic > 150)
            {
                MessageBox.Show("Диастолическое давление должно быть 40-150", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                tbDiastolic.Focus();
                return false;
            }
            if (!int.TryParse(tbPulse.Text, out int pulse) || pulse < 30 || pulse > 200)
            {
                MessageBox.Show("Пульс должен быть 30-200", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                tbPulse.Focus();
                return false;
            }
            if (!double.TryParse(tbSugar.Text, out double sugar) || sugar < 1.0 || sugar > 30.0)
            {
                MessageBox.Show("Сахар должен быть 1.0-30.0", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                tbSugar.Focus();
                return false;
            }
            return true;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateFields()) return;

            var date = dpDate.SelectedDate ?? DateTime.Today;
            var time = TimeSpan.TryParse(tbTime.Text, out var ts) ? ts : new TimeSpan(12, 0, 0);
            var dateTime = date.Add(time);

            var record = new Record
            {
                Id = _isEditMode ? _editingRecord.Id : 0,
                DateTime = dateTime,
                Systolic = int.Parse(tbSystolic.Text),
                Diastolic = int.Parse(tbDiastolic.Text),
                Pulse = int.Parse(tbPulse.Text),
                Sugar = double.Parse(tbSugar.Text),
                Meal = (MealTime)cbMeal.SelectedIndex,
                Comment = tbComment.Text
            };

            if (_isEditMode)
                _dataService.Update(record);
            else
                _dataService.Add(record);

            DialogResult = true;
            Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}