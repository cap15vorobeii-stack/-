﻿using System;
using System.ComponentModel;

namespace MedicalDiaryWPF.Models
{
    public class Record : INotifyPropertyChanged
    {
        private int _id;
        private DateTime _dateTime;
        private int _systolic;
        private int _diastolic;
        private int _pulse;
        private double _sugar;
        private MealTime _meal;
        private string _comment;

        public int Id
        {
            get => _id;
            set { _id = value; OnPropertyChanged(nameof(Id)); }
        }

        public DateTime DateTime
        {
            get => _dateTime;
            set { _dateTime = value; OnPropertyChanged(nameof(DateTime)); }
        }

        public int Systolic
        {
            get => _systolic;
            set { _systolic = value; OnPropertyChanged(nameof(Systolic)); }
        }

        public int Diastolic
        {
            get => _diastolic;
            set { _diastolic = value; OnPropertyChanged(nameof(Diastolic)); }
        }

        public int Pulse
        {
            get => _pulse;
            set { _pulse = value; OnPropertyChanged(nameof(Pulse)); }
        }

        public double Sugar
        {
            get => _sugar;
            set { _sugar = value; OnPropertyChanged(nameof(Sugar)); }
        }

        public MealTime Meal
        {
            get => _meal;
            set { _meal = value; OnPropertyChanged(nameof(Meal)); }
        }

        public string Comment
        {
            get => _comment;
            set { _comment = value; OnPropertyChanged(nameof(Comment)); }
        }

        public string DisplayInfo => $"{DateTime:dd.MM.yyyy HH:mm} | {Systolic}/{Diastolic} | {Pulse} уд/мин | {Sugar:F1} ммоль/л";

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    public enum MealTime
    {
        [Description("Натощак")]
        Fasting,
        [Description("Через 1 час")]
        After1Hour,
        [Description("Через 2 часа")]
        After2Hours
    }
}