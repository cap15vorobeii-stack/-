﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using LiveCharts;
using LiveCharts.Wpf;
using MedicalDiaryWPF.Controls;
using MedicalDiaryWPF.Models;
using MedicalDiaryWPF.Services;
using Newtonsoft.Json;

namespace MedicalDiaryWPF
{
    public partial class MainWindow : Window
    {
        private readonly DataService _dataService = new();

        public List<Record> Records => _dataService.Records;

        public ChartValues<int> PressureSystolic { get; set; } = new();
        public ChartValues<int> PressureDiastolic { get; set; } = new();
        public ChartValues<double> SugarValues { get; set; } = new();
        public List<string> DateLabels { get; set; } = new();

        public MainWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            var records = _dataService.Records.OrderBy(r => r.DateTime).ToList();

            dgRecords.ItemsSource = records;

            PressureSystolic.Clear();
            PressureDiastolic.Clear();
            SugarValues.Clear();
            DateLabels.Clear();

            foreach (var r in records)
            {
                var dateStr = r.DateTime.ToString("dd.MM\nHH:mm");
                DateLabels.Add(dateStr);
                PressureSystolic.Add(r.Systolic);
                PressureDiastolic.Add(r.Diastolic);
                SugarValues.Add(r.Sugar);
            }

            chartPressure.Update();
            chartSugar.Update();
        }

        private string GetMealDescription(MealTime meal) => meal switch
        {
            MealTime.Fasting => "Натощак",
            MealTime.After1Hour => "Через 1 час",
            MealTime.After2Hours => "Через 2 часа",
            _ => "—"
        };

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var form = new RecordForm(_dataService);
            if (form.ShowDialog() == true)
                LoadData();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (dgRecords.SelectedItem is Record selected)
            {
                var form = new RecordForm(_dataService, selected);
                if (form.ShowDialog() == true)
                    LoadData();
            }
            else
            {
                MessageBox.Show("Выберите запись для редактирования.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (dgRecords.SelectedItem is Record selected)
            {
                if (MessageBox.Show($"Удалить запись \"{selected.DisplayInfo}\"?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    _dataService.Delete(selected.Id);
                    LoadData();
                }
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnExportPdf_Click(object sender, RoutedEventArgs e)
        {
            if (!_dataService.Records.Any())
            {
                MessageBox.Show("Нет данных для экспорта.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            MessageBox.Show("Для экспорта в PDF установите пакет PdfSharp через NuGet:\n\n" +
                "Install-Package PdfSharp\n\n");
        }
    }
}