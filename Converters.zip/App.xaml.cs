﻿using System.Windows;

namespace MedicalDiaryWPF
{
    public partial class App : Application
    {
    }
}