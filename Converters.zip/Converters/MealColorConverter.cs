﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using MedicalDiaryWPF.Models;

namespace MedicalDiaryWPF.Converters
{
    public class MealColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is MealTime meal)
            {
                return meal switch
                {
                    MealTime.Fasting => new SolidColorBrush(Colors.Green),
                    MealTime.After1Hour => new SolidColorBrush(Colors.Orange),
                    MealTime.After2Hours => new SolidColorBrush(Colors.Red),
                    _ => new SolidColorBrush(Colors.Blue)
                };
            }
            return new SolidColorBrush(Colors.Gray);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}